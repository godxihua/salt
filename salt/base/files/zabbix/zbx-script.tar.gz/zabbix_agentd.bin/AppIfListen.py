#!/bin/env python
import os
import sys
import json
import re

def HELP():
    print '+----------------------------------------------+'
    print '| help:                                        |'
    print '|     python AppIfDiscovery.py [log|pid|port]  |'
    print '+----------------------------------------------+'
    sys.exit(1)

def factory(cmd):
    retval = []
    exce_cmd = os.popen(cmd)
    for line in exce_cmd.readlines():
        retval.append(line.strip())
    return retval

def main():#description
    list_argv = ['log','pid','port']
    if not sys.argv[1] in list_argv:
        HELP()
    argv = sys.argv[1]
    f = open('/proc/sys/net/ipv4/ip_local_port_range')
    min_port = 3000
    max_port = int(f.read().strip().split()[0]) - 1
    f.close()
    processes_info = {'log':[],'pid':[],'port':[]}
    ps = factory("ps -ef")
    ss = factory('ss -natpl | sed "1d"')
    lsof = factory('lsof')
    for s in ss:
        if int(s.split()[3].split(':')[-1]) <= max_port:
            process = {'user':'','id':[]}
            for process_lable in re.compile(r'\(?\((.*?)\)', re.S).findall(s.split()[-1]):
                process['user'] = process_lable.split(',')[0].strip('"')
                process['id'].append(process_lable.split(',')[1])
            process_port = s.split()[3].split(':')[-1]
            if process['user'] == 'zabbix_agentd' or process_port == '10050':
                continue
            for pid in process['id']:
                for p in ps:
                    if pid == p.split()[1]:
                        for l in lsof:
                            if re.match(r'.*log$', l) and l.split()[1] == pid:
                                processes_info['log'] += [{'{#PUSER}':process['user'],'{#PID}':pid,'{#PLOG}':l.split()[-1],'{#PDESCR}':p}]
                                lsof.remove(l) 
                        processes_info['pid'] += [{'{#PUSER}':process['user'],'{#PID}':pid,'{#PDESCR}':p}]
                        processes_info['port'] += [{'{#PUSER}':process['user'],'{#PID}':pid,'{#PLISTEN}':process_port,'{#PDESCR}':p}]
                        #ps.remove(p)
    print json.dumps({'data':processes_info[argv]},sort_keys=True,indent=4,separators=(',',':'))
if __name__ == '__main__':
    main()
