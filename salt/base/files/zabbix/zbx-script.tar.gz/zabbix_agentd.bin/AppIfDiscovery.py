#!/bin/env python
import os
import sys
import json
import re

def HELP():
    print '+----------------------------------------------+'
    print '| help:                                        |'
    print '|     python AppIfDiscovery.py [log|pid|port]  |'
    print '+----------------------------------------------+'
    sys.exit(1)

def factory(cmd):
    retval = []
    exce_cmd = os.popen(cmd)
    for line in exce_cmd.readlines():
        retval.append(line.strip())
    return retval

def main():
    list_argv = ['log','pid','port']
    if len(sys.argv) != 2 or not sys.argv[1] in list_argv:
        HELP()
    argv = sys.argv[1]
    f = open('/proc/sys/net/ipv4/ip_local_port_range')
    min_port = 3000
    max_port = int(f.read().strip().split()[0]) - 1
    f.close()
    #app = {'name':[],'path':[],'log':[],'pid':[],'port':[]}
    app = {'path':[],'log':[],'pid':[],'port':[]}
    list_del = ['bin','conf','lib','conf:']
    processes = factory("ps -ef |grep java | grep classpath | grep -v grep")
    ss = factory('ss -natpl')
    lsof = factory('lsof')
    for p in processes:
        index = p.split().index('-classpath')
        list_app_path = p.strip().split()[index + 1].split('/')[1:4]
        for str_del in list_del:
            try:
                list_app_path.remove(str_del)
            except ValueError:
                pass
        app_path = '/' + '/'.join(list_app_path)
        app_name = os.path.basename(app_path)
        app_pid = p.strip().split()[1]
        app['path'] += [{'{#APPNAME}':app_name,'{#APPPATH}':app_path}]
        app['pid'] += [{'{#APPNAME}':app_name,'{#APPPID}':app_pid}]
        for s in ss:
            if re.match(r'.*,%s,.*' % app_pid, s) and int(s.split()[3].split(':')[-1]) <= max_port and int(s.split()[3].split(':')[-1]) >= min_port:
                app_port = s.split()[3].split(':')[-1]
                app['port'] += [{'{#APPNAME}':app_name,'{#APPPORT}':app_port}]
                ss.remove(s)
        for l in lsof:
            if re.match(r'.*log$', l) and l.split()[1] == app_pid:
                app_log = l.split()[-1]
                app['log'] += [{'{#APPNAME}':app_name,'{#APPLOG}':app_log}]
                lsof.remove(l)
    print json.dumps({'data':app[argv]},sort_keys=True,indent=4,separators=(',',':'))

if __name__ == '__main__':
    main()
