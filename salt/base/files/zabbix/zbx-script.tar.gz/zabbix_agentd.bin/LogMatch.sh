#!/bin/bash

HELP() {
    echo 'bash LogMatch.sh Log Keyword Maxline'
}

if [ $# -ne 4 ]
then
    HELP
    exit 1
fi

if [ -n "$3" ] && [[ "$3" =~ ^[0-9]+$ ]]
then
    count=`tail -n "$3" "$1" | grep "$2" | wc -l`
else
    HELP
    exit 1
fi

echo $count

