#!/bin/bash

HELP() {
    echo 'bash LogMatchExact.sh Log Keyword Maxline Maxvalue'
}

if [ $# -ne 5 ]
then
    HELP
    exit 1
fi

count=0

if [ -n "$3" ] && [[ "$3" =~ ^[0-9]+$ ]] && [[ "$4" =~ ^[0-9]+$ ]]
then
    for line in `tail -n "$3" "$1" | grep "$2" | sed 's/ \+//g'`
    do
        value=`echo $line | sed "s/.*time\[\(.*[0-9]\)\].*/\1/"`
        if [ $value -ge $4 ]
        then
            count=$((count+1))
        fi
    done
else
    HELP
    exit 1
fi

echo $count

