#!/usr/bin/env python
# -*- coding : utf-8 -*-

import re
import sys
import jpype
from jpype import javax
import json

def HELP():
    print '+-------------------------------------+'
    print '| help:                               |'
    print '|     python JmxApi.py "name ip port" |'
    print '+-------------------------------------+'
    sys.exit(1)


class JmxApiException(Exception):
    pass

class JmxApi(object):
    def __init__(self, name, ip, port):
        self.__name = name
        self.__ip = ip
        self.__port = port
        self.__mbean_server_connection = self.__jmxApiInit(ip, port)
        self.data = self.__Domain_MBean_Attribute_Value()
        self.__object_list = ('Domain', 'MBean', 'Attribute')        
    
    def __Domain_MBean_Attribute_Value(self):
        data = []
        for domain in self.__mbean_server_connection.getDomains():
            for mbean in self.__mbean_server_connection.queryNames(javax.management.ObjectName(str(domain) + ':*'), None):
                for attribute in self.__mbean_server_connection.getMBeanInfo(mbean).getAttributes():
                    try:
                        data.append(
                                    {
                                     '{#NAME}':self.__name,
                                     '{#IP}':self.__ip,
                                     '{#PORT}':self.__port,
                                     '{#DOMAIN}':str(domain),
                                     '{#MBEAN}':str(mbean),
                                     '{#ATTRIBUTE}':str(attribute.getName()),
                                     '{#VALUE}':str(self.__mbean_server_connection.getAttribute(mbean, str(attribute.getName())))
                                     }
                                    )
                    except Exception:
                        pass
        return data
    
    def __jmxApiInit(self, ip, port):
        libjvm_so =  jpype.getDefaultJVMPath()
        if not jpype.isJVMStarted():
            jpype.startJVM(libjvm_so)
        url = 'service:jmx:rmi:///jndi/rmi://%s:%d/jmxrmi' % (ip, port)
        jmx_service_url =  javax.management.remote.JMXServiceURL(url)
        try:
            jmx_connector =  javax.management.remote.JMXConnectorFactory.connect(jmx_service_url)
        except Exception:
            raise JmxApiException("Connect to %s:%s error" % (ip, port))
        return jmx_connector.getMBeanServerConnection()

def main():
    try:
        if len(sys.argv) != 4 or not re.match(r'\d+\.\d+\.\d+\.\d+', sys.argv[2]) or not re.match('\d', sys.argv[3]):
            HELP()
    except IndexError:
        HELP()
    app_name = sys.argv[1]
    app_ip = sys.argv[2]
    app_port = int(sys.argv[3])
    japi = JmxApi(app_name, app_ip, app_port)
    print json.dumps({'data':japi.data},sort_keys=True,indent=4,separators=(',',':'))

if __name__ == '__main__':
    main()
